import httpx
import time
import re
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import json
import jwt as pyjwt

# ملفات protobuf لازم تكون موجودة في نفس المجلد
import my_pb2
import output_pb2
import data_pb2
import encode_id_clan_pb2
import reqClan_pb2

# -------------------- الإعدادات --------------------
freefire_version = "OB52"
key = bytes([89,103,38,116,99,37,68,69,117,104,54,37,90,99,94,56])
iv = bytes([54,111,121,90,68,114,50,50,69,51,121,99,104,106,77,37])

JWT_REGEX = re.compile(r'(eyJ[A-Za-z0-9_\-\.=]+)')

# -------------------- JWT --------------------
def extract_token(text):
    m = JWT_REGEX.search(text)
    return m.group(1) if m else None

def get_jwt_token(uid, password):
    try:
        oauth_url = "https://100067.connect.garena.com/oauth/guest/token/grant"
        payload = {
            'uid': str(uid),
            'password': password,
            'response_type': "token",
            'client_type': "2",
            'client_secret': "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
            'client_id': "100067"
        }
        headers = {
            'User-Agent': "GarenaMSDK/4.0.19P9(Android)",
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip"
        }
        res = httpx.post(oauth_url, data=payload, headers=headers, timeout=15.0)
        data = res.json()
        if "access_token" not in data:
            return None
        access_token = data["access_token"]
        open_id = data.get("open_id", "")
        for platform_type in range(1, 13):
            try:
                game_data = my_pb2.GameData()
                game_data.timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                game_data.game_name = "free fire"
                game_data.game_version = 1
                game_data.version_code = "1.108.3"
                game_data.os_info = "Android"
                game_data.device_type = "Handheld"
                game_data.network_provider = "wifi"
                game_data.connection_type = "WIFI"
                game_data.screen_width = 1280
                game_data.screen_height = 720
                game_data.dpi = "240"
                game_data.cpu_info = "ARM"
                game_data.total_ram = 4096
                game_data.gpu_name = "Adreno"
                game_data.gpu_version = "OpenGL"
                game_data.user_id = "Google"
                game_data.ip_address = "127.0.0.1"
                game_data.language = "en"
                game_data.open_id = open_id
                game_data.access_token = access_token
                game_data.platform_type = platform_type
                game_data.field_99 = str(platform_type)
                game_data.field_100 = str(platform_type)

                serialized = game_data.SerializeToString()
                cipher = AES.new(key, AES.MODE_CBC, iv)
                encrypted = cipher.encrypt(pad(serialized, AES.block_size))

                headers2 = {
                    "User-Agent": "Dalvik/2.1.0",
                    "Connection": "Keep-Alive",
                    "Content-Type": "application/octet-stream",
                    "X-Unity-Version": "2018.4.11f1",
                    "ReleaseVersion": freefire_version
                }

                r = httpx.post(
                    "https://loginbp.ggpolarbear.com/MajorLogin",
                    content=encrypted,
                    headers=headers2,
                    timeout=15.0
                )

                token = None
                try:
                    msg = output_pb2.Garena_420()
                    msg.ParseFromString(r.content)
                    token = getattr(msg, "token", None)
                except:
                    pass
                if not token:
                    token = extract_token(r.text)
                if token:
                    return token
                time.sleep(0.5)
            except:
                continue
        return None
    except Exception as e:
        print("JWT ERROR:", e)
        return None

# -------------------- Region --------------------
def get_region_from_jwt(token):
    try:
        decoded = pyjwt.decode(token, options={"verify_signature": False})
        return decoded.get("lock_region", "ME").upper()
    except:
        return "ME"

def get_region_url(region):
    region = region.upper()
    if region == "IND":
        return "https://client.ind.freefiremobile.com"
    elif region in ["BR", "US", "SAC", "NA"]:
        return "https://client.us.freefiremobile.com"
    return "https://clientbp.ggblueshark.com"

# -------------------- Clan --------------------
def create_join_payload(clan_id):
    msg = reqClan_pb2.MyMessage()
    msg.field_1 = int(clan_id)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(pad(msg.SerializeToString(), AES.block_size))

def get_clan_info(base_url, token, clan_id):
    try:
        msg = encode_id_clan_pb2.MyData()
        msg.field1 = int(clan_id)
        msg.field2 = 1
        cipher = AES.new(key, AES.MODE_CBC, iv)
        encrypted = cipher.encrypt(pad(msg.SerializeToString(), 16))
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/octet-stream",
            "User-Agent": "Dalvik/2.1.0"
        }
        r = httpx.post(f"{base_url}/GetClanInfoByClanID", headers=headers, content=encrypted)
        if r.status_code == 200:
            resp = data_pb2.response()
            resp.ParseFromString(r.content)
            return {
                "clan_name": getattr(resp, "special_code", "Unknown"),
                "clan_level": getattr(resp, "level", "Unknown")
            }
    except Exception as e:
        print("Clan Info Error:", e)
    return {"clan_name": "Unknown", "clan_level": "Unknown"}

# -------------------- Join --------------------
def join_clan(uid, password, clan_id):
    token = get_jwt_token(uid, password)
    if not token:
        return {"success": False, "message": "فشل في الحصول على التوكن"}
    region = get_region_from_jwt(token)
    base_url = get_region_url(region)
    clan_info = get_clan_info(base_url, token, clan_id)
    payload = create_join_payload(clan_id)
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/octet-stream",
        "User-Agent": "Dalvik/2.1.0"
    }
    r = httpx.post(f"{base_url}/RequestJoinClan", headers=headers, content=payload)
    return {
        "success": r.status_code == 200,
        "status": r.status_code,
        "uid": uid,
        "clan_id": clan_id,
        "region": region,
        "clan_name": clan_info["clan_name"],
        "clan_level": clan_info["clan_level"],
        "time": time.time()
    }

# -------------------- Main --------------------
if __name__ == "__main__":
    print("=== سكريبت انضمام كلان Free Fire ===")
    uid = input("ادخل UID: ")
    password = input("ادخل كلمة المرور: ")
    clan_id = input("ادخل Clan ID: ")

    result = join_clan(uid, password, clan_id)
    print(json.dumps(result, indent=4, ensure_ascii=False))