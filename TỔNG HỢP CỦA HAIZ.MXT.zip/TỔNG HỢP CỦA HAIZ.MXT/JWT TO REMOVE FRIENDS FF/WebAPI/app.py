from flask import Flask, request, jsonify, render_template_string
import requests
import json
import base64
import urllib3
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import Remove_pb2  # Ensure this file is in the same folder

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)


KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
IV  = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

def encrypt_payload(data):
    cipher = AES.new(KEY, AES.MODE_CBC, IV)
    return cipher.encrypt(pad(data, AES.block_size))

def get_server_url(region):
    if region == "IND":
        return "https://client.ind.freefiremobile.com"
    elif region in ["BR", "US", "SAC", "NA"]:
        return "https://client.us.freefiremobile.com"
    elif region in ["SG", "BD"]:
        return "https://clientbp.ggpolarbear.com"
    else:
        return "https://clientbp.ggblueshark.com"

def decode_jwt(token):
    try:
        parts = token.split('.')
        if len(parts) < 2: return None, None
        payload_part = parts[1]
        missing_padding = len(payload_part) % 4
        if missing_padding: payload_part += '=' * (4 - missing_padding)
        decoded = json.loads(base64.b64decode(payload_part))
        return decoded.get("account_id"), decoded.get("lock_region")
    except:
        return None, None

@app.route('/')
def index():
    return render_template_string('''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <!-- Chrome, Firefox OS and Opera ka header colour change karne ke liye -->
        <meta name="theme-color" content="#28a745">
        <!-- Windows Phone ke liye -->
        <meta name="msapplication-navbutton-color" content="#28a745">
        <!-- iOS Safari ke liye -->
        <meta name="apple-mobile-web-app-status-bar-style" content="#28a745">

        <title>Garena Friend Remover API</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; background: #f0f2f5; color: #333; }
            
            .header { 
                background: #28a745; /* Green Color */
                color: white; 
                padding: 40px 20px; 
                text-align: center; 
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            }

            .container { max-width: 800px; margin: -30px auto 40px; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
            
            h1 { font-size: 2.2em; margin-bottom: 10px; }
            h3 { color: #28a745; margin: 25px 0 10px; border-left: 5px solid #28a745; padding-left: 10px; }
            
            code { background: #f8f9fa; border: 1px solid #ddd; padding: 4px 8px; border-radius: 5px; font-family: 'Courier New', Courier, monospace; color: #d63384; font-weight: bold; font-size: 1.1em; display: inline-block; margin: 10px 0; }
            
            .endpoint-box { background: #e9f7ef; padding: 15px; border-radius: 8px; border: 1px dashed #28a745; margin: 15px 0; }
            
            pre { background: #2d3436; color: #fab1a0; padding: 20px; border-radius: 8px; overflow-x: auto; font-size: 0.9em; box-shadow: inset 0 2px 10px rgba(0,0,0,0.3); }
            .json-key { color: #55efc4; }
            .json-val { color: #ffeaa7; }

            ul { list-style-type: none; margin-left: 5px; }
            ul li { margin-bottom: 10px; padding-left: 20px; position: relative; }
            ul li::before { content: "✔"; color: #28a745; position: absolute; left: 0; font-weight: bold; }
            
            .footer { text-align: center; margin-top: 20px; color: #777; font-size: 0.9em; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🚀 Garena Friend Remover</h1>
            <p>High-speed API to clear your friend list</p>
        </div>

        <div class="container">
            <h3>📌 API Endpoint</h3>
            <div class="endpoint-box">
                <code>GET /remove?jwt={token}&uid={target_uid}</code>
            </div>

            <h3>📝 Query Parameters</h3>
            <ul>
                <li><strong>jwt</strong>: Your account Bearer token (without 'Bearer ' prefix).</li>
                <li><strong>uid</strong>: The Garena UID of the friend you want to delete.</li>
            </ul>

            <h3>✅ Success Response Example</h3>
            <pre>
{
  <span class="json-key">"success"</span>: <span class="json-val">true</span>,
  <span class="json-key">"message"</span>: <span class="json-val">"UID 12345678 removed successfully"</span>,
  <span class="json-key">"region"</span>: <span class="json-val">"BD"</span>
}</pre>

            <h3>❌ Error Response Example</h3>
            <pre>
{
  <span class="json-key">"success"</span>: <span class="json-val">false</span>,
  <span class="json-key">"message"</span>: <span class="json-val">"BR_FRIEND_NOT_FOUND"</span>
}</pre>
            
            <div class="footer">
                &copy; 2026 Friend Remover API 
            </div>
        </div>
    </body>
    </html>
    ''')

@app.route('/remove', methods=['GET'])
def remove_friend():
    jwt_token = request.args.get('jwt')
    target_uid = request.args.get('uid')

    if not jwt_token or not target_uid:
        return jsonify({"success": False, "message": "Missing jwt or uid"}), 400

    my_id, region = decode_jwt(jwt_token)
    if not my_id or not region:
        return jsonify({"success": False, "message": "Invalid Token"}), 401

    url = f"{get_server_url(region)}/RemoveFriend"
    
    try:
        req = Remove_pb2.CSRemoveFriendReq()
        req.remover = int(my_id)
        req.removee = int(target_uid)
        encrypted_data = encrypt_payload(req.SerializeToString())

        headers = {
            "X-GA": "v1 1",
            "Content-Type": "application/octet-stream",
            "Authorization": f"Bearer {jwt_token}",
            "ReleaseVersion": "OB53",
            "User-Agent": "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)"
        }

        resp = requests.post(url, data=encrypted_data, headers=headers, verify=False, timeout=10)
        
        if resp.status_code == 200:
            return jsonify({"success": True, "message": "Removed successfully", "region": region}), 200
        else:
            try:
                err = resp.content.decode('utf-8').strip()
            except:
                err = f"Server Error {resp.status_code}"
            return jsonify({"success": False, "message": err}), 400

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

if __name__ == "__main__":
    app.run()