import requests
import json
import base64
import urllib3
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from google.protobuf.json_format import MessageToJson
import Remove_pb2

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
IV  = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

def encrypt_payload(data):
    cipher = AES.new(KEY, AES.MODE_CBC, IV)
    return cipher.encrypt(pad(data, AES.block_size))

def get_server_url(region):
    if region == "IND":
        return "https://client.ind.freefiremobile.com"
    elif region in ["BR", "US", "SAC", "NA"]:
        return "https://client.us.freefiremobile.com"
    elif region in ["SG", "BD"]:
        return "https://clientbp.ggpolarbear.com"
    else:
        return "https://clientbp.ggblueshark.com"

def decode_jwt(token):
    try:
        payload_b64 = token.split('.')[1]
        missing_padding = len(payload_b64) % 4
        if missing_padding:
            payload_b64 += '=' * (4 - missing_padding)
        decoded = json.loads(base64.b64decode(payload_b64))
        return decoded.get("account_id"), decoded.get("lock_region")
    except Exception as e:
        print(f"[-] JWT Decode Error: {e}")
        return None, None

def main():
    print("--- GARENA FRIEND REMOVER ---")
    jwt_token = input("🔑 Enter JWT Token: ").strip()
    target_uid = input("🎯 Enter UID to Remove: ").strip()

    remover_id, region = decode_jwt(jwt_token)
    if not remover_id or not region:
        print("[-] Invalid Token.")
        return

    base_url = get_server_url(region)
    full_url = f"{base_url}/RemoveFriend"

    print(f"[*] Detected ID: {remover_id} | Region: {region}")
    print(f"[*] Target URL: {full_url}")

    req = Remove_pb2.CSRemoveFriendReq()
    req.remover = int(remover_id)
    req.removee = int(target_uid)

    encrypted_data = encrypt_payload(req.SerializeToString())

    headers = {
        "X-GA": "v1 1",
        "Content-Type": "application/octet-stream",
        "Authorization": f"Bearer {jwt_token}",
        "ReleaseVersion": "OB53",
        "User-Agent": "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)"
    }

    try:
        resp = requests.post(full_url, data=encrypted_data, headers=headers, verify=False, timeout=10)
        
        print(f"\n[*] Response Status: {resp.status_code}")

        if resp.status_code == 200:
            res_pb = RemoveFriend_pb2.CSRemoveFriendRes()
            res_pb.ParseFromString(resp.content)
            json_out = MessageToJson(res_pb, preserving_proto_field_name=True)
            print("\n✅ SUCCESS! FRIEND REMOVED:")
            print(json_out)
        
        else:
            print("\n❌ GARENA ERROR DETECTED:")
            try:
                error_text = resp.content.decode('utf-8').strip()
                print(f"Server Message: {error_text}")
            except:
                print(f"Raw Hex Error: {resp.content.hex().upper()}")
            
            try:
                res_err = RemoveFriend_pb2.CSRemoveFriendRes()
                res_err.ParseFromString(resp.content)
                if res_err.error_msg:
                    print(f"Parsed Error Field: {res_err.error_msg}")
            except:
                pass

    except Exception as e:
        print(f"[-] Request Error: {e}")

if __name__ == "__main__":
    main()