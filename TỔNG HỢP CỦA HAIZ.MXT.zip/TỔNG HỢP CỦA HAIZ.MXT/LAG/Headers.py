import requests , os , psutil , sys , jwt , pickle , json , binascii , time , urllib3 , BesTo_Keys , base64 , datetime , re ,socket , threading , packets_pb2
from protobuf_decoder.protobuf_decoder import Parser
from C4 import *
from datetime import datetime
from google.protobuf.timestamp_pb2 import Timestamp
from concurrent.futures import ThreadPoolExecutor
from threading import Thread

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning) 

def send_likes(uid):
    try:
        likes_api_response = requests.get(f"http://72.62.132.233:5007/apclikes?uid={uid}")

        if likes_api_response.status_code == 200:
            api_data = likes_api_response.json()

            if api_data.get("LikesGivenByAPI", 0) == 0:
                # حالة الحد اليومي (لون أحمر)
                return {
                    "status": "failed",
                    "message": (
                        f"[C][B][FF0000]________________________\n"
                        f" ❌ الحد اليومي لإرسال الإعجابات!\n"
                        f" حاول مرة أخرى بعد 24 ساعة\n"
                        f"________________________"
                    )
                }
            else:
                # حالة النجاح مع التفاصيل (لون أخضر)
                return {
                    "status": "ok",
                    "message": (
                        f"[C][B][00FF00]________________________\n"
                        f" ✅ تم إضافة {api_data['LikesGivenByAPI']} إعجاب\n"
                        f" الاسم: {api_data['PlayerNickname']}\n"
                        f" الإعجابات السابقة: {api_data['LikesbeforeCommand']}\n"
                        f" الإعجابات الجديدة: {api_data['LikesafterCommand']}\n"
                        f"________________________"
                    )
                }
        else:
            # حالة الفشل العامة (لون أحمر)
            return {
                "status": "failed",
                "message": (
                    f"[C][B][FF0000]________________________\n"
                    f" ❌ خطأ في الإرسال!\n"
                    f" تأكد من صحة اليوزر ID\n"
                    f"________________________"
                )
            }
    except Exception:
        # حالة فشل الاتصال بالـ API
        return {
            "status": "failed",
            "message": (
                f"[C][B][FF0000]________________________\n"
                f" ❌ فشل الاتصال بخادم الإعجابات!\n"
                f" حاول مرة أخرى لاحقًا\n"
                f"________________________"
            )
        }
    
# أضف هاتين الدالتين في نهاية الملف

def validate_uid(uid, Token):
    """
     تتحقق من صحة المعرف عن طريق محاولة جلب بيانات اللاعب
    """
    data = bytes.fromhex(encrypt_api(f"08{Encrypt_Uid(uid)}1007"))
    url = "https://clientbp.common.ggbluefox.com/GetPlayerPersonalShow"
    headers = {
        'X-Unity-Version': '2018.4.11f1',
        'ReleaseVersion': 'OB52',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-GA': 'v1 1',
        'Authorization': f'Bearer {Token}',
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)',
        'Host': 'clientbp.ggblueshark.com',
        'Connection': 'Keep-Alive'
    }
    try:
        response = requests.post(url , headers=headers , data=data ,verify=False)
        if response.status_code == 200 or response.status_code == 201:
            # محاولة فك تشفير المحتوى للتأكد من أنه رد صالح
            json.loads(DeCode_PackEt(binascii.hexlify(response.content).decode('utf-8')))
            return {"status": "ok"}
        return {"status": "failed"}
    except Exception:
        return {"status": "failed"}

def send_spam(uid, token):
    """
    تقوم بإرسال السبام بعد التحقق من صحة المعرف
    """
    try:
        # أولاً، التحقق من صحة المعرف باستخدام دالة التحقق الجديدة
        info_response = validate_uid(uid, token)

        if info_response.get('status') != "ok":
            return (
                f"[c][b][FF0000]-----------------------------------\n"
                f"خطأ في المعرف: {Besto_Fix(uid)}\n"
                f"الرجاء التحقق من الرقم\n"
                f"-----------------------------------\n"
            )

        # ثانيًا، إرسال الطلب إلى الرابط الصحيح
        api_url = f"http://72.62.132.233:8080/spam?id={uid}"
        response = requests.get(api_url)

        # ثالثًا، التحقق من نجاح الطلب
        if response.status_code == 200:
            return (
                f"[c][b][{generate_random_hex_color()}]-----------------------------------\n"
                f"تم إرسال طلب صداقة بنجاح ✅\n"
                f"إلى: {Besto_Fix(uid)}\n"
                f"-----------------------------------\n"
            )
        else:
            return (
                f"[c][b][FF0000]-----------------------------------\n"
                f"فشل الإرسال (كود الخطأ: {response.status_code})\n"
                f"-----------------------------------\n"
            )

    except requests.exceptions.RequestException as e:
        # معالجة أخطاء الاتصال بالشبكة
        return (
            f"[c][b][FF0000]-----------------------------------\n"
            f"فشل الاتصال بالخادم:\n"
            f"{str(e)}\n"
            f"-----------------------------------\n"
        )

def GeT_Name(uid , Token , key , iv):
    data = bytes.fromhex(encrypt_api(f"08{Encrypt_Uid(uid)}1007"))
    url = "https://clientbp.common.ggbluefox.com/GetPlayerPersonalShow"
    headers = {
        'X-Unity-Version': '2018.4.11f1',
        'ReleaseVersion': 'OB52',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-GA': 'v1 1',
        'Authorization': f'Bearer {Token}',
        'Content-Length': '16',
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)',
        'Host': 'clientbp.ggblueshark.com',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip'
    }
    response = requests.post(url , headers=headers , data=data ,verify=False)
    if response.status_code == 200 or 201:
        import binascii
        packet = binascii.hexlify(response.content).decode('utf-8')
        BesTo_data = json.loads(DeCode_PackEt(packet))      
        try:
            a1 = BesTo_data["1"]["data"]["3"]["data"]
            return a1
        except:
        	return f'[b][c][ff0000] - No InFo For Uid > {Besto_Fix(uid)} ! '   
        	  	
def GeT_PLayer_InFo(uid , Token , clients , Guild_Uid , client_id , key , iv , status):
    data = bytes.fromhex(encrypt_api(f"08{Encrypt_Uid(uid)}1007"))
    url = "https://clientbp.common.ggbluefox.com/GetPlayerPersonalShow"
    headers = {
        'X-Unity-Version': '2018.4.11f1',
        'ReleaseVersion': 'OB52',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-GA': 'v1 1',
        'Authorization': f'Bearer {Token}',
        'Content-Length': '16',
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)',
        'Host': 'clientbp.ggblueshark.com',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip'}
    response = requests.post(url , headers=headers , data=data ,verify=False)
    if response.status_code == 200 or 201:
        packet = binascii.hexlify(response.content).decode('utf-8')
        BesTo_data =  json.loads(DeCode_PackEt(packet))
        NoCLan = False   
        try:        
            a1 = str(BesTo_data["1"]["data"]["1"]["data"])
            a2 = BesTo_data["1"]["data"]["21"]["data"]
            a3 = BesTo_data["1"]["data"]["3"]["data"]
            player_server = BesTo_data["1"]["data"]["5"]["data"]
            player_bio = BesTo_data["9"]["data"]["9"]["data"]
            player_level = BesTo_data["1"]["data"]["6"]["data"]
            account_date = datetime.fromtimestamp(BesTo_data["1"]["data"]["44"]["data"]).strftime("%I:%M %p - %d/%m/%y")
            last_login = datetime.fromtimestamp(BesTo_data["1"]["data"]["24"]["data"]).strftime("%I:%M %p - %d/%m/%y")
            try:
                clan_id = BesTo_data["6"]["data"]["1"]["data"]
                clan_name = BesTo_data["6"]["data"]["2"]["data"]
                clan_leader = BesTo_data["6"]["data"]["3"]["data"]
                clan_level = BesTo_data["6"]["data"]["4"]["data"]
                clan_members_num = BesTo_data["6"]["data"]["6"]["data"]
                clan_leader_name = BesTo_data["7"]["data"]["3"]["data"]                       
            except:
                NoCLan = True
            if NoCLan:
            	a = f'''
[b][c][90EE90] [SuccessFully] - Get PLayer s'InFo !

[FFFF00][1] - ProFile InFo :
[ffffff]	
 Name : {Besto_Fix(a3)}
 Uid : {Besto_Fix(a1)}
 Likes : {Besto_Fix(a2)}
 LeveL : {player_level}
 Server : {player_server}
 Bio : {Besto_Fix(player_bio)}
 Creating : {Besto_Fix(account_date)}
 LasT LoGin : {Besto_Fix(last_login)}
 
  [90EE90]Dev : C4 Team OfficieL\n''' 
            	a = a.replace('[i]','[c]')
            	if status == 'clan':
            	    clients.send(bytes.fromhex(BesTo_Pa_CLan(a , Guild_Uid , Decrypt_Uid(client_id) , key , iv)))   
            	elif status == 'prv':
            	    clients.send(bytes.fromhex(BesTo_Pa_Private(a , client_id , key , iv)))
            	            
            else:
            	          	                        
            	a = f'''
[b][c][90EE90] [SuccessFully] - Get PLayer s'InFo !

[FFFF00][1] - ProFile InFo :
[ffffff]	
 Name : {Besto_Fix(a3)}
 Uid : {Besto_Fix(a1)}
 Likes : {Besto_Fix(a2)}
 LeveL : {player_level}
 Server : {player_server}
 Bio : {Besto_Fix(player_bio)}
 Creating : {Besto_Fix(account_date)}
 LasT LoGin : {Besto_Fix(last_login)}

[b][c][FFFF00][2] - Guild InFo :
[ffffff]
 Guild Name : {Besto_Fix(clan_name)}
 Guild Uid : {Besto_Fix(clan_id)}
 Guild LeveL : {clan_level}
 Guild Members : {clan_members_num}
 Leader s'Uid : {Besto_Fix(clan_leader)}
 Leader s'Name : {Besto_Fix(clan_leader_name)}

  [90EE90]Dev : C4 Team OfficieL\n'''
            	a = a.replace('[i]','[c]')
            	if status == 'clan':
            	    clients.send(bytes.fromhex(BesTo_Pa_CLan(a , Guild_Uid , Decrypt_Uid(client_id) , key , iv)))   
            	elif status == 'prv':
            	    clients.send(bytes.fromhex(BesTo_Pa_Private(a , client_id , key , iv)))  	    
                                       
        except Exception as e:
           return f'\n[b][c] - No InFo For Uid : {Besto_Fix(uid)}\n'   
    else:return f'\n[b][c] - No InFo For Uid : {Besto_Fix(uid)}\n'
    
def DeLet_Uid(id , Tok):
    print(f' Done FuckinG > {id} ')
    url = 'https://clientbp.common.ggbluefox.com/RemoveFriend'
    headers = {
        'X-Unity-Version': '2018.4.11f1',
        'ReleaseVersion': 'OB52',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-GA': 'v1 1',
        'Authorization': f'Bearer {Tok}',
        'Content-Length': '16',
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)',
        'Host': 'clientbp.ggblueshark.com',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip'}
    data = bytes.fromhex(encrypt_api(f'08a7c4839f1e10{Encrypt_Uid(id)}'))
    ResPonse = requests.post(url , headers=headers , data=data , verify=False)    
    if ResPonse.status_code == 400 and 'BR_FRIEND_NOT_SAME_REGION' in ResPonse.text:
        return f'[b][c]Id : {Besto_Fix(id)} Not In Same Region !'
    elif ResPonse.status_code == 200:
        return f'[b][c]Good Response Done Delete Id : {Besto_Fix(id)} !'
    else:
        return f'[b][c]Erorr !'
                                                        
def ChEck_The_Uid(id):
    Api = requests.get("https://panel-g2ccathtf6gdcmdw.polandcentral-01.azurewebsites.net/Uids")
    if Api.status_code not in [200, 201]: 
        return False    
    lines = Api.text.splitlines()    
    for i, line in enumerate(lines):
        if f' - Uid : {id}' in line:
            expire, status = None, None
            for sub_line in lines[i:]:
                if "Expire In" in sub_line: 
                    expire = re.search(r"Expire In\s*:\s*(.*)", sub_line).group(1).strip()
                if "Status" in sub_line: 
                    status = re.search(r"Status\s*:\s*(\w+)", sub_line).group(1)
                if expire and status: return status, expire
            return False
    return False
    
def check_banned_status(player_id):
    """
    Checks the ban status of a player using an external API.
    """
    url = f"http://amin-team-api.vercel.app/check_banned?player_id={player_id}"
    try:
        response = requests.get(url, timeout=15)
        if response.status_code == 200:
            # ترجع قاموس يحتوي على الحالة والاسم
            return response.json()
        else:
            # ترجع لا شيء في حال وجود خطأ من الـ API
            return None
    except requests.RequestException:
        # ترجع لا شيء في حال فشل الاتصال
        return None
        
def get_player_info_new_api(uid):
    """
    Fetches detailed player info from an external API.
    """
    try:
        url = f"http://72.62.132.233:3000/{uid}"
        response = requests.get(url, timeout=15)

        if response.status_code == 200:
            data = response.json()
            # The API response nests info in a list, this handles it
            if "basicinfo" in data and isinstance(data["basicinfo"], list) and len(data["basicinfo"]) > 0:
                data["basic_info"] = data["basicinfo"][0]
            else:
                return {"status": "wrong_id"}

            if "claninfo" in data and isinstance(data["claninfo"], list) and len(data["claninfo"]) > 0:
                data["clan_info"] = data["claninfo"][0]
            else:
                data["clan_info"] = None # Use None to indicate no clan

            return {"status": "ok", "info": data}
        else:
            return {"status": "wrong_id"} # API returned an error
    except (requests.RequestException, json.JSONDecodeError):
        return {"status": "error"} # Connection or JSON parsing error        
        
def send_likes_from_api(uid):
    """
    Calls the external API to send likes and returns a formatted message string.
    """
    try:
        response = requests.get(f"https://like-tawny.vercel.app/apclikes?uid={uid}", timeout=20)
        if response.status_code == 200:
            api_data = response.json()
            if api_data.get("LikesGivenByAPI", 0) == 0:
                return (f"[C][B][FF0000]فشل الإرسال إلى {uid}\nربما تم الوصول للحد اليومي لهذا الحساب.")
            else:
                return (f"[C][B][00FF00]تم إرسال {api_data['LikesGivenByAPI']} لايك بنجاح إلى:\n{api_data['PlayerNickname']}")
        else:
            return f"[C][B][FF0000]خطأ في الإرسال إلى {uid}\nتأكد من صحة الـ ID."
    except requests.RequestException:
        return f"[C][B][FF0000]خطأ في الاتصال بخادم اللايكات."
        
                
                        
# Headers.py

# ... (احذف النسخ القديمة من الدالتين التاليتين إذا كانت موجودة) ...

def start_visit_request(uid):
    """
    ترسل طلب GET وتتأكد من نجاحه عن طريق فحص status code.
    """
    url = f"http://72.62.132.233:5006/add?id={uid}"
    try:
        # سننتظر الرد لمدة 5 ثواني كحد أقصى
        response = requests.get(url, timeout=5)
        # نتأكد أن الخادم رد بنجاح (status code 200)
        if response.status_code == 200:
            print(f"Visit request for UID {uid} sent successfully.")
            return True
        else:
            print(f"Visit request for UID {uid} failed with status: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        # طباعة أي خطأ يحدث أثناء إرسال الطلب
        print(f" - Error sending visit request: {e}")
        return False

def start_graveyard_request(uid):
    """
    ترسل طلب GET وتتأكد من نجاحه عن طريق فحص status code.
    """
    url = f"http://72.62.132.233:3001/add?id={uid}"
    try:
        # سننتظر الرد لمدة 5 ثواني كحد أقصى
        response = requests.get(url, timeout=5)
        # نتأكد أن الخادم رد بنجاح (status code 200)
        if response.status_code == 200:
            print(f"Graveyard request for UID {uid} sent successfully.")
            return True
        else:
            print(f"Graveyard request for UID {uid} failed with status: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        # طباعة أي خطأ يحدث أثناء إرسال الطلب
        print(f" - Error sending graveyard request: {e}")
        return False
        
# Headers.py

# ... (باقي الأكواد الموجودة في الملف) ...

def start_friend_spam_request(uid):
    """
    ترسل طلب GET وتتأكد من نجاحه عن طريق فحص status code.
    """
    url = f"http://72.62.132.233:5005/start?id={uid}"
    try:
        # سننتظر الرد لمدة 5 ثواني كحد أقصى
        response = requests.get(url, timeout=5)
        # نتأكد أن الخادم رد بنجاح (status code 200)
        if response.status_code == 200:
            print(f"Friend spam request for UID {uid} sent successfully.")
            return True
        else:
            print(f"Friend spam request for UID {uid} failed with status: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        # طباعة أي خطأ يحدث أثناء إرسال الطلب
        print(f" - Error sending friend spam request: {e}")
        return False        