from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import binascii
import requests
from flask import Flask, jsonify, request
from GetWishListItems_pb2 import CSGetWishListItemsRes
import uid_generator_pb2
from datetime import datetime
import threading
import time

app = Flask(__name__)

# ================= JWT STATIC =================

JWT_URL = "https://amin-king-friend.vercel.app/token?uid=4151617822&password=9DD3258FAA0E5D0BE10CCC51F47987F5974CB0FBF7662E2CF5B9139A4D714A2C"
jwt_token = None
jwt_lock = threading.Lock()

def load_jwt():
    global jwt_token
    try:
        r = requests.get(JWT_URL, timeout=10)
        r.raise_for_status()
        data = r.json()
        token = data.get("token")
        if not token:
            raise Exception("JWT token not found")

        with jwt_lock:
            jwt_token = token

        print("✅ JWT refreshed successfully")

    except Exception as e:
        print(f"❌ JWT refresh failed: {e}")

def jwt_refresher():
    while True:
        time.sleep(8 * 60 * 60)  # 8 ساعات
        load_jwt()

# ================= UTILS =================

def convert_timestamp(ts):
    return datetime.utcfromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

key = "Yg&tc%DEuh6%Zc^8"
iv  = "6oyZDr22E3ychjM%"

def encrypt_aes(hex_data):
    cipher = AES.new(key.encode()[:16], AES.MODE_CBC, iv.encode()[:16])
    padded = pad(bytes.fromhex(hex_data), AES.block_size)
    return binascii.hexlify(cipher.encrypt(padded)).decode()

# ================= API CALL =================

API_ENDPOINT = "https://clientbp.ggpolarbear.com/GetWishListItems"

def call_api(payload_hex):
    with jwt_lock:
        token = jwt_token

    headers = {
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)',
        'Connection': 'Keep-Alive',
        'Expect': '100-continue',
        'Authorization': f'Bearer {jwt_token}',
        'X-Unity-Version': '2018.4.11f1',
        'X-GA': 'v1 1',
        'ReleaseVersion': 'OB53',
        'Content-Type': 'application/x-www-form-urlencoded',
    }

    res = requests.post(
        API_ENDPOINT,
        headers=headers,
        data=bytes.fromhex(payload_hex),
        timeout=10
    )
    res.raise_for_status()
    return res.content

# ================= ROUTE =================

@app.route("/wish", methods=["GET"])
def wish():
    try:
        uid = request.args.get("uid")
        if not uid:
            return jsonify({"error": "uid required"}), 400

        msg = uid_generator_pb2.uid_generator()
        msg.saturn_ = int(uid)
        msg.garena = 1

        hex_data = binascii.hexlify(msg.SerializeToString()).decode()
        encrypted = encrypt_aes(hex_data)

        raw = call_api(encrypted)

        res = CSGetWishListItemsRes()
        res.ParseFromString(raw)

        wishlist = [
            {
                "item_id": i.item_id,
                "release_time": convert_timestamp(i.release_time)
            }
            for i in res.items
        ]

        return jsonify({
            "uid": uid,
            "wishlist": wishlist
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ================= RUN =================

if __name__ == "__main__":
    load_jwt()

    t = threading.Thread(target=jwt_refresher, daemon=True)
    t.start()

    app.run(host="0.0.0.0", port=5552)